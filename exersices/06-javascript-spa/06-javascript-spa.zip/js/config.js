var api_url = '//api.themoviedb.org/3/',
    api_poster_url = '//image.tmdb.org/t/p/w154/',
    api_key = '20e949c0a8e65d7f48c565a02b3c6b6c';
